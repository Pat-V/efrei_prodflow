Projet système de suivi de lignes de productions

Un grand laboratoire pharmaceutique veut mettre en place un outil de suivi de ses lignes de production. En effet, elle produit plus de 2 millions de médicaments par jour de différents types sur près d’un millier de lignes de production répartis sur des sites à travers le monde. Des retards sur une ligne peuvent impacter la production d'autres.

Or il arrive parfois que des pannes mettent du temps à être remontées. Vous allez donc faire un outil qui permettra de faire le suivi des lignes de productions, de faire remonter des incidents à travers un système de ticket et d’affecter des équipes ou personnes sur un ticket donné.

Des statistiques sur les incidents pourront être faites afin de voir si des formations ou des interventions pour améliorer la qualité sont nécessaires sur un site donné.

Partie 0 - Préambule

installer nodejs
vérifier que vous pouvez lancer la commande node et npm dans un terminal
créer un dossier prodflow.
Initialiser un repository git avec la commande git init
Sur github ajouter un repository vide
connecter votre repository local à votre repository distant avec la commande git remote add
créer un dossier src contenant un fichier backend.js
faire un console.log pour afficher hello
lancer le fichier
commit le fichier et faire un push sur votre git
créer un dossier public à la racine du projet et mettre un fichier index.html
Partie 1 - backend sans base de donnée

Dans cette partie on va stocker nos données comme des brutes dans une variable globale.

Récupérer le code du fichier suivant et lancer le fichier avec node.js
Avec postman envoyer une requête get sur la première route
Avec postman envoyer une requête post sur la première route
Créer une variable globale contenant un objet qui contiendra les donnée du site
nom
adresse (également un objet)
un tableau contenant une liste des lignes de productions.
Chaque ligne de production sera également un objet avec
le nombre d’unité produite par minute
le numéro de la ligne
Modifier le code du backend pour que l’url /site-info renvoie sous forme de json les données du site de production
Faire en sorte d’avoir une méthode /new-production-line qui ajoute une nouvelle ligne de production au site. Par défaut le nombre d’unité produite est de 0
Faire en sorte d’avoir une méthode /production-line/:id/update qui permet de mettre à jour le nombre d’unité produite par l’unité de production
Partie 2 - le front

en se basant sur https://expressjs.com/en/starter/static-files.html, faire en sorte que le serveur node donne accès aux fichiers contenu dans le dossier public 2. Mettre un peu de html dans le fichier index.html et vérifier qu'il s'affiche

      3. dans le fichier html du dossier public :

Créer une fonction Site(siteData) qui retourne un html contenant les informations générales du site
Créer une fonction displayHTML(html, targetElement) qui ajouter à targetElement un contenu html. Vous utiliserez pour cela createElement et .innerHTML
Créer un objet JS contenant des informations du js et utiliser votre fonction pour afficher l’interface
On va maintenant récupérer les données du backend au lieu de les coder en dur. Avec la fonction fetch envoyer une requête au backend pour récupérer les données et de la même manière faire en sorte d’afficher les données récupérées.
Partie 3 - connexion à la base de donnée

On veut désormais connecter notre backend à une base de donnée

Avec npm install, installer le connecteur correspondant à votre base de donnée. Utiliser le flag --save 2. vérifier que dans package.json la librairie est bien présente

     3. A l’aide de la documentation, créer une fonction qui crée une connexion à la base de donnée.

      4. Faire une fonction qui insére la donnée d’un site dans mongodb. La tester

      5. Faire une fonction qui récupère la donnée d’un site dans mongodb

Lien base de donnée / express

En utilisant les fonctions précédentes, faire en sorte que les endpoints de votre serveur express se connectent à la base de donnée
Partie 4

faire en sorte d’améliorer ce magnifique projet. Cela peut inclure
gérer plusieurs sites
avoir un système d’authentification
Détailler le nombre de production par type et par site
Permettre à des utilisateurs d’ajouter un ticket d’incident et d’afficher les tickets par ligne de production et par site
toute idée découverte en discutant avec le métier (vous même, votre collègue ou votre formateur)
