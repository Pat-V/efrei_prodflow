import "../styles/Banner.css";
import logo from "../assets/logo.png";

export default function Banner() {
  const title = "ProdFlow";

  return (
    <div className="pf-banner">
      <img src={logo} alt={title} className="pf-logo" />
      <h1> {title}</h1>
    </div>
  );
}
