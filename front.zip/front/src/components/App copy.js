import Banner from "./Banner";
import SiteList from "./Sites";

export default function App() {
  return (
    <div>
      <header>
        <Banner />
        <SiteList />
      </header>
    </div>
  );
}
