import { sites } from "../datas/sites";
import "../styles/Sites.css";

export default function SiteList() {
  const siteList = sites.reduce(
    (acc, siteName) =>
      acc.includes(siteName.site_name) ? acc : acc.concat(siteName.site_name),
    []
  );

  return (
    <div>
      <ul className="pf-site-list">
        {siteList.map((site_name) => (
          <li className="pf-site-item" key={site_name}>
            <h2>{site_name}</h2>
          </li>
        ))}
      </ul>
    </div>
  );
}
